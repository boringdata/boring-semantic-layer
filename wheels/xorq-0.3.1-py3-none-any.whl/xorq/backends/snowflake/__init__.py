import contextlib
import functools
import itertools
import warnings
from pathlib import Path
from typing import Any

import pandas as pd
import pyarrow as pa
import sqlglot as sg
import sqlglot.expressions as sge
import toolz

import xorq.vendor.ibis.expr.api as api
import xorq.vendor.ibis.expr.schema as sch
import xorq.vendor.ibis.expr.types as ir
from xorq.common.utils.logging_utils import get_logger
from xorq.expr.relations import (
    prepare_create_table_from_expr,
)
from xorq.vendor.ibis.backends.snowflake import _SNOWFLAKE_MAP_UDFS
from xorq.vendor.ibis.backends.snowflake import Backend as IbisSnowflakeBackend
from xorq.vendor.ibis.expr.operations.relations import (
    Namespace,
)


try:
    from enum import StrEnum
except ImportError:
    from strenum import StrEnum


logger = get_logger(__name__)


class SnowflakeAuthenticator(StrEnum):
    # https://docs.snowflake.com/en/developer-guide/node-js/nodejs-driver-options#label-nodejs-auth-options
    password = "none"
    mfa = "username_password_mfa"
    keypair = "snowflake_jwt"
    sso = "externalbrowser"
    # oauth = "oauth"
    # oauth2 = "oauth_authorization_code"


@functools.wraps(IbisSnowflakeBackend.do_connect)
def wrapped_do_connect(self, create_object_udfs: bool = None, **kwargs: Any):
    from xorq.common.utils.snowflake_keypair_utils import maybe_decrypt_private_key
    from xorq.common.utils.snowflake_utils import default_create_object_udfs

    if create_object_udfs is None:
        create_object_udfs = default_create_object_udfs

    if "private_key" in kwargs:
        kwargs = maybe_decrypt_private_key(kwargs)
    return IbisSnowflakeBackend.do_connect(
        self, create_object_udfs=create_object_udfs, **kwargs
    )


class Backend(IbisSnowflakeBackend):
    _top_level_methods = (
        "connect_env",
        "connect_env_mfa",
        "connect_env_password",
        "connect_env_keypair",
    )

    @staticmethod
    def connect_env(
        passcode=None,
        authenticator=None,
        **kwargs,
    ):
        from xorq.common.utils.snowflake_utils import make_connection

        return make_connection(
            authenticator=authenticator,
            passcode=passcode,
            **kwargs,
        )

    connect_env_password = staticmethod(
        toolz.curry(connect_env, authenticator=SnowflakeAuthenticator.password)
    )

    connect_env_mfa = staticmethod(
        toolz.curry(connect_env, authenticator=SnowflakeAuthenticator.mfa)
    )

    connect_env_keypair = staticmethod(
        toolz.curry(connect_env, authenticator=SnowflakeAuthenticator.keypair)
    )

    def table(self, *args, **kwargs):
        table = super().table(*args, **kwargs)
        op = table.op()
        if op.namespace == Namespace(None, None):
            (catalog, database) = (self.current_catalog, self.current_database)
            table = op.copy(**{"namespace": Namespace(catalog, database)}).to_expr()
        return table

    def create_table(
        self,
        name: str,
        obj: pd.DataFrame | pa.Table | ir.Table | None = None,
        *,
        schema: sch.Schema | None = None,
        database: str | None = None,
        temp: bool = False,
        overwrite: bool = False,
        comment: str | None = None,
    ) -> ir.Table:
        """Create a table in Snowflake.

        Parameters
        ----------
        name
            Name of the table to create
        obj
            The data with which to populate the table; optional, but at least
            one of `obj` or `schema` must be specified
        schema
            The schema of the table to create; optional, but at least one of
            `obj` or `schema` must be specified
        database
            The name of the database in which to create the table; if not
            passed, the current database is used.
        temp
            Create a temporary table
        overwrite
            If `True`, replace the table if it already exists, otherwise fail
            if the table exists
        comment
            Add a comment to the table

        """
        if obj is None and schema is None:
            raise ValueError("Either `obj` or `schema` must be specified")

        quoted = self.compiler.quoted

        if database is None:
            target = sg.table(name, quoted=quoted)
            catalog = db = database
        else:
            db = self._warn_and_create_table_loc(database=database)
            (catalog, db) = (db.catalog, db.db)
            target = sg.table(name, db=db, catalog=catalog, quoted=quoted)

        column_defs = [
            sge.ColumnDef(
                this=sg.to_identifier(name, quoted=quoted),
                kind=self.compiler.type_mapper.from_ibis(typ),
                constraints=(
                    None
                    if typ.nullable
                    else [sge.ColumnConstraint(kind=sge.NotNullColumnConstraint())]
                ),
            )
            for name, typ in (schema or {}).items()
        ]

        if column_defs:
            target = sge.Schema(this=target, expressions=column_defs)

        properties = []

        if temp:
            properties.append(sge.TemporaryProperty())

        if comment is not None:
            properties.append(sge.SchemaCommentProperty(this=sge.convert(comment)))

        if obj is not None:
            if not isinstance(obj, ir.Expr):
                table = api.memtable(obj)
            else:
                if catalog is not None and db is not None:
                    table = prepare_create_table_from_expr(
                        self, obj, database=(catalog, db)
                    )
                else:
                    table = prepare_create_table_from_expr(self, obj)

            self._run_pre_execute_hooks(table)

            query = self.compiler.to_sqlglot(table)
        else:
            query = None

        create_stmt = sge.Create(
            kind="TABLE",
            this=target,
            replace=overwrite,
            properties=sge.Properties(expressions=properties),
            expression=query,
        )

        with self._safe_raw_sql(create_stmt):
            pass

        return self.table(name, database=(catalog, db))

    do_connect = wrapped_do_connect

    def _setup_session(self, *, session_parameters, create_object_udfs: bool):
        con = self.con

        # Configure Snowflake telemetry to use xorq's TracerProvider
        # This ensures Snowpark operations create child spans under the current trace
        # instead of creating separate root traces
        try:
            from opentelemetry import trace

            tracer_provider = trace.get_tracer_provider()

            # Snowflake connector uses OpenTelemetry internally
            # We need to ensure it uses our TracerProvider
            if hasattr(con, '_telemetry_client'):
                # Set the tracer provider on the connection's telemetry client
                con._telemetry_client._tracer_provider = tracer_provider
                logger.debug("Configured Snowflake telemetry to use xorq's TracerProvider")

            # Also try to configure the global snowflake.connector telemetry
            try:
                import snowflake.connector
                if hasattr(snowflake.connector, 'telemetry'):
                    snowflake.connector.telemetry.set_tracer_provider(tracer_provider)
            except (ImportError, AttributeError):
                pass

        except Exception as e:
            logger.debug(f"Could not configure Snowflake telemetry: {e}")

        # enable multiple SQL statements by default
        session_parameters.setdefault("MULTI_STATEMENT_COUNT", 0)
        # don't format JSON output by default
        session_parameters.setdefault("JSON_INDENT", 0)

        # overwrite session parameters that are required for ibis + snowflake
        # to work
        session_parameters.update(
            dict(
                # Use Arrow for query results
                PYTHON_CONNECTOR_QUERY_RESULT_FORMAT="arrow_force",
                # JSON output must be strict for null versus undefined
                STRICT_JSON_OUTPUT=True,
                # Timezone must be UTC
                TIMEZONE="UTC",
            ),
        )

        with contextlib.closing(con.cursor()) as cur:
            cur.execute(
                "ALTER SESSION SET {}".format(
                    " ".join(f"{k} = {v!r}" for k, v in session_parameters.items())
                )
            )

        # snowflake activates a database on creation, so reset it back
        # to the original database and schema
        if con.database and "/" in con.database:
            (catalog, db) = con.database.split("/")
            use_stmt = sge.Use(
                kind="SCHEMA",
                this=sg.table(db, catalog=catalog, quoted=self.compiler.quoted),
            ).sql(dialect=self.name)
            with contextlib.closing(con.cursor()) as cur:
                try:
                    cur.execute(use_stmt)
                except Exception as e:  # noqa: BLE001
                    warnings.warn(f"Unable to set catalog,db: {e}")

        if create_object_udfs:
            create_stmt = sge.Create(
                kind="DATABASE", this="ibis_udfs", exists=True
            ).sql(dialect=self.name)

            stmts = [
                create_stmt,
                # snowflake activates a database on creation, so reset it back
                # to the original database and schema
                *itertools.starmap(self._make_udf, _SNOWFLAKE_MAP_UDFS.items()),
            ]

            stmt = ";\n".join(stmts)
            with contextlib.closing(con.cursor()) as cur:
                try:
                    cur.execute(stmt)
                except Exception as e:  # noqa: BLE001
                    warnings.warn(
                        f"Unable to create Ibis UDFs, some functionality will not work: {e}"
                    )
        # without this self.current_{catalog,database} is not synchronized with con.{database,schema}
        with contextlib.closing(con.cursor()) as cur:
            try:
                cur.execute("SELECT CURRENT_TIME")
            except Exception:  # noqa: BLE001
                pass

    @property
    def adbc(self):
        from xorq.common.utils.snowflake_utils import SnowflakeADBC

        adbc = SnowflakeADBC(self)
        return adbc

    def read_record_batches(
        self,
        record_batches: pa.RecordBatchReader,
        table_name: str | None = None,
        temporary: bool = False,
        mode: str = "create",
        database=None,
        **kwargs: Any,
    ) -> ir.Table:
        logger.info(
            "reading record batches with SnowflakeADBC",
            **{
                "table_name": table_name,
                "temporary": temporary,
                "mode": mode,
                **kwargs,
            },
        )

        snowflake_adbc = self.adbc
        snowflake_adbc.adbc_ingest(
            table_name, record_batches, mode=mode, database=database, **kwargs
        )
        return self.table(table_name, database=database)

    # Snowflake Stage Operations
    # ===========================

    def create_stage(
        self,
        name: str,
        *,
        temporary: bool = False,
        if_not_exists: bool = True,
        encryption: str = "SNOWFLAKE_SSE",
        comment: str | None = None,
    ) -> None:
        """Create an internal Snowflake stage.

        Parameters
        ----------
        name
            Name of the stage to create (with or without @ prefix)
        temporary
            Create a temporary stage (dropped at session end)
        if_not_exists
            Don't error if stage already exists
        encryption
            Encryption type: 'SNOWFLAKE_SSE' or 'SNOWFLAKE_FULL'
        comment
            Optional comment for the stage

        Examples
        --------
        >>> con.create_stage("my_cache_stage")
        >>> con.create_stage("@temp_stage", temporary=True)
        """
        # Ensure name starts with @
        stage_name = name if name.startswith("@") else f"@{name}"

        # Build CREATE STAGE statement
        temp_clause = "TEMPORARY " if temporary else ""
        if_not_exists_clause = "IF NOT EXISTS " if if_not_exists else ""
        encryption_clause = f"ENCRYPTION = (TYPE = '{encryption}')"
        comment_clause = f"COMMENT = '{comment}'" if comment else ""

        sql = (
            f"CREATE {temp_clause}STAGE {if_not_exists_clause}{stage_name} "
            f"{encryption_clause}"
        )
        if comment_clause:
            sql += f" {comment_clause}"

        self.raw_sql(sql).fetchall()
        logger.info(f"Created stage: {stage_name}")

    def drop_stage(self, name: str, *, if_exists: bool = True) -> None:
        """Drop a Snowflake stage.

        Parameters
        ----------
        name
            Name of the stage to drop (with or without @ prefix)
        if_exists
            Don't error if stage doesn't exist

        Examples
        --------
        >>> con.drop_stage("my_cache_stage")
        >>> con.drop_stage("@old_stage")
        """
        stage_name = name if name.startswith("@") else f"@{name}"
        if_exists_clause = "IF EXISTS " if if_exists else ""

        sql = f"DROP STAGE {if_exists_clause}{stage_name}"
        self.raw_sql(sql).fetchall()
        logger.info(f"Dropped stage: {stage_name}")

    def list_stage(self, name: str, pattern: str | None = None) -> list[tuple]:
        """List files in a Snowflake stage.

        Parameters
        ----------
        name
            Stage name or path (e.g., '@stage' or '@stage/folder')
        pattern
            Optional file pattern to filter results (e.g., '*.parquet')

        Returns
        -------
        list[tuple]
            List of tuples containing file information

        Examples
        --------
        >>> con.list_stage("@my_stage")
        >>> con.list_stage("@my_stage/folder", pattern="*.parquet")
        """
        stage_path = name if name.startswith("@") else f"@{name}"

        sql = f"LIST {stage_path}"
        if pattern:
            sql += f" PATTERN = '{pattern}'"

        result = self.raw_sql(sql).fetchall()
        return result

    def put(
        self,
        local_path: str | Path,
        stage_path: str,
        *,
        overwrite: bool = True,
        auto_compress: bool = False,
        parallel: int = 4,
    ) -> list[tuple]:
        """Upload a local file to a Snowflake stage.

        Parameters
        ----------
        local_path
            Local file path to upload
        stage_path
            Target stage path (e.g., '@stage' or '@stage/folder')
        overwrite
            Overwrite existing files
        auto_compress
            Automatically compress files during upload
        parallel
            Number of threads for parallel upload

        Returns
        -------
        list[tuple]
            PUT command result information

        Examples
        --------
        >>> con.put("data.parquet", "@my_stage")
        >>> con.put("/tmp/data.parquet", "@my_stage/folder", overwrite=True)
        """
        local_path = Path(local_path).absolute()
        stage_target = stage_path if stage_path.startswith("@") else f"@{stage_path}"

        sql = (
            f"PUT file://{local_path} {stage_target} "
            f"OVERWRITE={str(overwrite).upper()} "
            f"AUTO_COMPRESS={str(auto_compress).upper()} "
            f"PARALLEL={parallel}"
        )

        result = self.raw_sql(sql).fetchall()
        logger.info(f"Uploaded {local_path} to {stage_target}")
        return result

    def get(
        self,
        stage_path: str,
        local_dir: str | Path,
        *,
        parallel: int = 10,
        pattern: str | None = None,
    ) -> list[tuple]:
        """Download files from a Snowflake stage to a local directory.

        Parameters
        ----------
        stage_path
            Source stage path (e.g., '@stage/file.parquet' or '@stage/folder/')
        local_dir
            Target local directory
        parallel
            Number of threads for parallel download
        pattern
            Optional file pattern to filter downloads

        Returns
        -------
        list[tuple]
            GET command result information

        Examples
        --------
        >>> con.get("@my_stage/data.parquet", "/tmp")
        >>> con.get("@my_stage/folder/", "/tmp", pattern="*.parquet")
        """
        local_dir = Path(local_dir).absolute()
        local_dir.mkdir(parents=True, exist_ok=True)

        stage_source = stage_path if stage_path.startswith("@") else f"@{stage_path}"

        sql = f"GET {stage_source} file://{local_dir}/ PARALLEL={parallel}"
        if pattern:
            sql += f" PATTERN = '{pattern}'"

        result = self.raw_sql(sql).fetchall()
        logger.info(f"Downloaded {stage_source} to {local_dir}")
        return result

    def remove(self, stage_path: str, *, pattern: str | None = None) -> list[tuple]:
        """Remove files from a Snowflake stage.

        Parameters
        ----------
        stage_path
            Stage path to remove (e.g., '@stage/file.parquet' or '@stage/folder/')
        pattern
            Optional file pattern to filter removals

        Returns
        -------
        list[tuple]
            REMOVE command result information

        Examples
        --------
        >>> con.remove("@my_stage/old_data.parquet")
        >>> con.remove("@my_stage/folder/", pattern="*.tmp")
        """
        stage_target = stage_path if stage_path.startswith("@") else f"@{stage_path}"

        sql = f"REMOVE {stage_target}"
        if pattern:
            sql += f" PATTERN = '{pattern}'"

        result = self.raw_sql(sql).fetchall()
        logger.info(f"Removed {stage_target}")
        return result


def connect(*args, **kwargs):
    con = Backend(*args, **kwargs)
    con.reconnect()
    return con
