"""
Snowflake Stage Storage utilities for xorq.

This module provides a ParquetStorage-compatible cache implementation
that stores parquet files in Snowflake internal stages using PUT/GET commands.
Works in any environment with Snowflake access (local dev, notebooks, SPCS, etc).
"""

import tempfile
from pathlib import Path

import pyarrow.parquet as pq
from attrs import field, frozen
from attrs.validators import instance_of

from xorq.caching import CacheStorage
from xorq.common.utils.backend_utils import _backend_init


def rbr_from_fs(fs_path: Path):
    """Read parquet file as RecordBatchReader from filesystem path."""
    return pq.ParquetFile(fs_path).iter_batches()


def rbr_to_fs(fs_path: Path, rbr, **kwargs):
    """Write RecordBatchReader to parquet file at filesystem path."""
    with pq.ParquetWriter(fs_path, rbr.schema, **kwargs) as writer:
        for batch in rbr:
            writer.write_batch(batch)


@frozen
class _SnowflakeStageStorage(CacheStorage):
    """
    Internal storage implementation using Snowflake stages.

    Uses Snowflake PUT/GET/LIST/REMOVE commands to manage parquet cache files
    in internal stages. Works in any environment with Snowflake connection.

    Attributes:
        source: Snowflake Backend connection (provides auth and access control)
        stage_name: Name of the internal stage (e.g., "@my_cache_stage")
        folder: Optional subfolder within the stage for organizing cache files
    """

    source = field(
        validator=instance_of(object),  # Should be BaseBackend but avoiding circular import
        factory=_backend_init,
    )
    stage_name: str = field(validator=instance_of(str))
    folder: str = field(default="", validator=instance_of(str))

    def __attrs_post_init__(self):
        """Validate configuration and ensure stage exists."""
        # Ensure stage_name starts with @
        if not self.stage_name.startswith("@"):
            raise ValueError(f"stage_name must start with '@', got: {self.stage_name}")

        # Verify the stage exists
        try:
            # LIST will fail if stage doesn't exist
            self.source.list_stage(self.stage_name)
        except Exception as e:
            raise ValueError(
                f"Stage {self.stage_name} does not exist or is not accessible. "
                f"Create it with: con.create_stage('{self.stage_name}'); Error: {e}"
            )

    def _get_stage_path(self, key: str) -> str:
        """Get full stage path for a cache key (e.g., '@stage/folder/key.parquet')."""
        if self.folder:
            return f"{self.stage_name}/{self.folder}/{key}.parquet"
        return f"{self.stage_name}/{key}.parquet"

    def key_exists(self, key: str) -> bool:
        """Check if a cache entry exists."""
        stage_path = self._get_stage_path(key)
        try:
            result = self.source.list_stage(stage_path)
            return len(result) > 0
        except Exception:
            # If LIST fails, file doesn't exist
            return False

    def _get(self, key: str):
        """Retrieve cached value and return as operation."""
        # Use GET command to download to temp location, then read
        with tempfile.TemporaryDirectory() as tmpdir:
            stage_path = self._get_stage_path(key)
            tmpdir_path = Path(tmpdir)

            # Download from stage using Backend.get()
            self.source.get(stage_path, tmpdir_path)

            # Snowflake GET downloads files with same name
            local_file = tmpdir_path / f"{key}.parquet"
            rbr = rbr_from_fs(local_file)
            op = self.source.read_record_batches(rbr, table_name=key).op()
            return op

    def _put(self, key: str, value):
        """Store value in cache and return self._get(key)."""
        # Use PUT command to upload from temp file
        with tempfile.NamedTemporaryFile(
            suffix=".parquet", delete=False, mode="wb"
        ) as tmp:
            tmp_path = Path(tmp.name)

        try:
            # Write to temp file
            rbr = value.to_expr().to_pyarrow_batches()
            rbr_to_fs(tmp_path, rbr)

            # Upload using Backend.put()
            stage_target = self.stage_name
            if self.folder:
                stage_target = f"{stage_target}/{self.folder}"

            self.source.put(
                tmp_path, stage_target, overwrite=True, auto_compress=False
            )

            return self._get(key)
        finally:
            # Clean up temp file
            if tmp_path.exists():
                tmp_path.unlink()

    def _drop(self, key: str):
        """Delete cached value."""
        stage_path = self._get_stage_path(key)
        try:
            self.source.remove(stage_path)
        except Exception:
            # If REMOVE fails, file may not exist - that's ok
            pass
