"""
OpenTelemetry utilities with automatic Snowflake Trail integration.

This module configures OpenTelemetry tracing with automatic Snowflake integration,
enabling traces, metrics, and logs to be collected and stored in Snowflake Trail.

Architecture:
------------
When running in Snowpark Container Services (SPCS), your code runs in isolated
containers managed by Snowflake. Snowflake provides:

1. **Managed OTel Collector** - Runs on Snowflake infrastructure (NOT localhost)
   - Accessible via gRPC endpoints injected as environment variables
   - Collects traces, metrics, and logs from your containers
   - Publishes telemetry to account-level Event Tables

2. **Event Tables** - Dedicated tables storing all collected telemetry
   - Queryable using standard SQL
   - Viewable in Snowsight's Traces & Logs UI
   - Supports trace propagation between SPCS and Warehouse workloads

Snowflake Trace ID Format:
--------------------------
Traces MUST use Snowflake's trace ID format to:
- Be viewable in Snowflake Trail UI
- Enable performant time-based lookups in Event Tables
- Support trace propagation across Snowflake components

The SnowflakeTraceIdGenerator creates 16-byte big-endian IDs with:
- Timestamp in the four highest-order bytes (for efficient querying)
- Random bits in remaining bytes (for uniqueness)

Reference: https://pypi.org/project/snowflake-telemetry-python/

SPCS Context Detection:
-----------------------
Snowflake automatically populates these environment variables in containers:
- OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: gRPC endpoint for metrics
- OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: gRPC endpoint for traces

When detected, this module:
- Uses SnowflakeTraceIdGenerator (required for Trail)
- Routes telemetry to Snowflake's gRPC collector (insecure=True)
- Publishes to Event Tables configured for your account

Configuration:
-------------
OTEL_USE_SNOWFLAKE_TRACE_ID environment variable:
- "true"/"1"/"yes": Force enable Snowflake Trace IDs
- "false"/"0"/"no": Disable Snowflake Trace IDs
- Empty/unset: Auto-enable if snowflake-telemetry-python available (default)

OTEL_EXPORTER_OTLP_PROTOCOL environment variable:
- "grpc": Use gRPC protocol (default in SPCS, port 4317)
- "http/protobuf": Use HTTP protocol (port 4318)
"""

import os
import sys

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
    OTLPSpanExporter as GRPCSpanExporter,
)
from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
    OTLPSpanExporter as HTTPSpanExporter,
)
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
)


try:
    from snowflake.telemetry.trace import SnowflakeTraceIdGenerator

    SNOWFLAKE_TELEMETRY_AVAILABLE = True
except ImportError:
    SNOWFLAKE_TELEMETRY_AVAILABLE = False

from xorq.common.utils.env_utils import (
    EnvConfigable,
    env_templates_dir,
)


def localhost_and_listening(uri):
    import socket
    import urllib

    parsed = urllib.parse.urlparse(uri)
    localhost = "localhost"
    if parsed.hostname == localhost:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind((localhost, parsed.port))
        except OSError:
            return True
        else:
            return False
    return None


def is_snowpark_context():
    """
    Detect if running in Snowpark context by checking for Snowflake-provided
    OTEL environment variables.

    When running in Snowflake service containers, Snowflake automatically populates
    these environment variables with the OTel collector endpoints:
    - OTEL_EXPORTER_OTLP_METRICS_ENDPOINT
    - OTEL_EXPORTER_OTLP_TRACES_ENDPOINT

    Returns:
        bool: True if running in Snowpark, False otherwise
    """
    return bool(
        os.environ.get("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT")
        or os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")
    )


def should_use_snowflake_trace_id():
    """
    Determine if Snowflake Trace ID generator should be used.

    Snowflake Trace IDs are required for traces to be viewable in Snowflake Trail
    and to enable performant lookup in event tables. The 16-byte ID (big endian)
    contains a timestamp in the four highest-order bytes for efficient querying.

    The Snowflake Trace ID generator is used when:
    1. Running in Snowpark context (automatically detected), OR
    2. Explicitly enabled via OTEL_USE_SNOWFLAKE_TRACE_ID environment variable, OR
    3. Default behavior when snowflake-telemetry-python is available

    Returns:
        bool: True if Snowflake Trace ID generator should be used
    """
    # Always use in Snowpark context
    if is_snowpark_context():
        return True

    # Check explicit configuration
    otel_config = OTELConfig.from_env()
    use_snowflake_trace_id = otel_config.get("OTEL_USE_SNOWFLAKE_TRACE_ID", "").lower()

    # Explicit enable
    if use_snowflake_trace_id in ("true", "1", "yes"):
        return True

    # Explicit disable
    if use_snowflake_trace_id in ("false", "0", "no"):
        return False

    # Default: use if available (ensures compatibility with Snowflake Trail)
    return SNOWFLAKE_TELEMETRY_AVAILABLE


def get_otlp_protocol():
    """
    Determine the OTLP protocol to use (grpc or http/protobuf).

    Snowflake supports both gRPC (typically port 4317) and HTTP (typically port 4318)
    protocols for OTLP. The protocol is determined by:
    1. OTEL_EXPORTER_OTLP_PROTOCOL environment variable, OR
    2. Inference from the endpoint URL port (4317=grpc, 4318=http)
    3. Default to http/protobuf

    Returns:
        str: "grpc" or "http/protobuf"
    """
    # Check explicit protocol configuration
    protocol = os.environ.get("OTEL_EXPORTER_OTLP_PROTOCOL", "").lower()
    if protocol in ("grpc", "http/protobuf"):
        return protocol

    # Infer from Snowflake-provided endpoint if in Snowpark context
    if is_snowpark_context():
        endpoint = os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "")
        if ":4317" in endpoint:
            return "grpc"
        elif ":4318" in endpoint:
            return "http/protobuf"

    # Default to http/protobuf (most compatible)
    return "http/protobuf"


OTELConfig = EnvConfigable.subclass_from_env_file(
    env_templates_dir.joinpath(".env.otel.template")
)
otel_config = OTELConfig.from_env()


resource_attributes = {
    SERVICE_NAME: otel_config.OTEL_SERVICE_NAME,
}

# Add execution ID if available (for SPCS and other execution contexts)
# This allows filtering traces by execution in Snowflake Trail:
# WHERE RESOURCE_ATTRIBUTES:"execution.id"::STRING = '{execution_id}'
execution_id = os.environ.get("EXECUTION_ID")
if execution_id:
    resource_attributes["execution.id"] = execution_id

resource = Resource(attributes=resource_attributes)

# Configure Snowflake Trace ID generator
# Snowflake Trace IDs use a special format (16-byte big endian with timestamp in
# the four highest-order bytes) that enables:
# - Viewing traces in Snowflake Trail
# - Performant lookups in event tables
# - Time-based trace querying and analysis
if should_use_snowflake_trace_id() and SNOWFLAKE_TELEMETRY_AVAILABLE:
    trace_id_generator = SnowflakeTraceIdGenerator()
    provider = TracerProvider(resource=resource, id_generator=trace_id_generator)
else:
    provider = TracerProvider(resource=resource)

# Determine the OTEL exporter to use
# Priority order:
# 1. Snowpark context: Use Snowflake-provided OTel collector (gRPC, insecure)
# 2. Configured endpoint: Use user-configured OTEL_ENDPOINT_URI (protocol varies)
# 3. Console fallback: Log to console/devnull for local development
if is_snowpark_context():
    # SPCS (Snowpark Container Services): route to Snowflake's OTel collector
    # Snowflake provides gRPC endpoints on their infrastructure (NOT localhost)
    # and publishes telemetry to the account-level Event Table
    snowpark_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")
    if snowpark_endpoint:
        # Use gRPC exporter with insecure=True as per Snowflake documentation
        # The collector runs on Snowflake's managed infrastructure
        exporter = GRPCSpanExporter(endpoint=snowpark_endpoint, insecure=True)
    else:
        # Fallback if endpoint not available (shouldn't happen in Snowpark)
        exporter = ConsoleSpanExporter(out=sys.stdout)
elif otel_config["OTEL_ENDPOINT_URI"] and localhost_and_listening(
    otel_config["OTEL_ENDPOINT_URI"]
):
    # User-configured endpoint (e.g., local OTel collector, Grafana Cloud, etc.)
    # Choose protocol based on configuration or inference
    protocol = get_otlp_protocol()
    if protocol == "grpc":
        exporter = GRPCSpanExporter(endpoint=otel_config["OTEL_ENDPOINT_URI"])
    else:
        exporter = HTTPSpanExporter(endpoint=otel_config["OTEL_ENDPOINT_URI"])
else:
    # Local development: console logging or discard traces
    exporter = ConsoleSpanExporter(
        out=sys.stdout
        if otel_config["OTEL_EXPORTER_CONSOLE_FALLBACK"]
        else open(os.devnull, "w")
    )

processor = BatchSpanProcessor(exporter)
provider.add_span_processor(processor)
trace.set_tracer_provider(provider)


# Register shutdown handler to ensure spans are flushed
# This is critical in SPCS where containers may terminate quickly
import atexit


def shutdown_telemetry():
    """Flush and shutdown telemetry providers.

    This ensures all pending spans are exported before the process exits,
    which is especially important in short-lived SPCS containers.
    """
    try:
        provider.force_flush(timeout_millis=5000)
        provider.shutdown()
    except Exception:  # noqa: BLE001
        pass  # Ignore errors during shutdown


atexit.register(shutdown_telemetry)


# Creates a tracer from the global tracer provider
tracer = trace.get_tracer("xorq.tracer")
