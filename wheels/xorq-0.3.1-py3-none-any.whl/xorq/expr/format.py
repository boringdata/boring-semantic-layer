"""XORQ-native expression formatting utilities."""

import json as _json

from xorq.vendor.ibis.common.graph import Node


def string(expr) -> str:
    """Return the Ibis REPL formatter output for an expression as plain text."""
    try:
        # Use the non-interactive pretty formatter
        return expr._noninteractive_repr()
    except Exception:
        # Fallback to default repr
        return repr(expr)


def json(expr) -> str:
    """
    Return a JSON string of the logical-plan at the Ibis relational level,
    filtering out non-relation operators (e.g. WindowFunction, UDF internals).
    ExprScalarUDF nodes embed a hidden computed_kwargs_expr subtree.
    """
    from xorq.common.utils.graph_utils import bfs
    from xorq.expr.udf import ExprScalarUDF
    from xorq.vendor.ibis.expr.operations import Relation

    # Build a full breadth-first graph of all nodes
    graph = bfs(expr.op())

    # Helper: serialize a subtree fully (no filtering) bottom-up, using Ibis's own BFS
    from xorq.vendor.ibis.common.graph import bfs as ibis_bfs

    def _full_subtree(root: Node) -> dict:
        subgraph = ibis_bfs(root)
        subjson: dict[Node, dict] = {}
        for n in reversed(list(subgraph.keys())):
            subjson[n] = {
                "op": type(n).__name__,
                "children": [subjson[c] for c in subgraph[n]],
            }
        return subjson[root]

    node_json: dict[Node, dict] = {}

    # Serialize bottom-up so child payloads are ready when serializing parents
    for node in reversed(list(graph.keys())):
        payload: dict[str, object] = {"op": type(node).__name__}
        # ExprScalarUDF nodes embed a hidden computed_kwargs_expr subtree
        if isinstance(node, ExprScalarUDF):
            cke = node.computed_kwargs_expr.op()
            # inline the full computed_kwargs_expr subtree (all ops)
            payload["computed_kwargs_expr"] = _full_subtree(cke)
            # for UDF nodes, include only Relation children except the CKE subtree
            children = [
                c for c in graph[node] if c is not cke and isinstance(c, Relation)
            ]
        else:
            # only include Relation nodes in the generic children list
            children = [c for c in graph[node] if isinstance(c, Relation)]

        # include the remaining generic children payloads
        # only include serialized children to avoid ordering gaps
        payload["children"] = [node_json[c] for c in children if c in node_json]

        node_json[node] = payload

    # Dump the JSON for the root node
    return _json.dumps(node_json[expr.op()])


def lineage_json(expr) -> str:
    """Return a JSON string of per-column lineage trees for an expression."""
    from xorq.common.utils.lineage_utils import build_column_trees

    def _node_to_dict(node):
        return {
            "op": type(node.op).__name__,
            "children": [_node_to_dict(c) for c in node.children],
        }

    trees = build_column_trees(expr)
    payload = {col: _node_to_dict(tree) for col, tree in trees.items()}
    return _json.dumps(payload)