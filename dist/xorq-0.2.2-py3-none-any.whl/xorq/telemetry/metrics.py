"""
TelemetryCollector: collects in-memory metrics for XORQ Flight Server
and displays real-time metrics in the terminal.
"""
import resource
import sys
import threading
import time
from collections import deque

import pyarrow as pa
from opentelemetry import metrics


# ANSI color codes
RESET = "\033[0m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"

class TelemetryCollector:
    """
    Collects throughput, latency, data transfer, row count, error, and connection metrics
    for a FlightServer. Displays real-time metrics in the terminal and exports via OTEL.
    """
    def __init__(self, interval=2.0, window=60.0, compact=False, display=True):
        self.interval = float(interval)
        self.window = float(window)
        self.compact = compact
        self.display = display
        # In-memory data structures
        self.requests = deque()
        self.latencies = deque()
        self.bytes = deque()
        self.rows = deque()
        self.errors = deque()
        self.total_requests = 0
        self.total_bytes = 0
        self.total_rows = 0
        self.total_errors = 0
        self.current_connections = 0
        self.total_connections = 0
        # Setup OTEL metrics instruments
        meter = metrics.get_meter(__name__)
        self._req_counter = meter.create_counter(
            "flight_server_requests_total", unit="1"
        )
        self._latency_hist = meter.create_histogram(
            "flight_server_request_latency_ms", unit="ms"
        )
        self._bytes_counter = meter.create_counter(
            "flight_server_data_bytes_total", unit="bytes"
        )
        self._rows_counter = meter.create_counter(
            "flight_server_rows_total", unit="1"
        )
        self._errors_counter = meter.create_counter(
            "flight_server_errors_total", unit="1"
        )
        self._conn_updown = meter.create_up_down_counter(
            "flight_server_active_connections", unit="1"
        )
        self._lock = threading.Lock()

    def set_server(self, server):  # noqa: ARG001
        """Associate this collector with a FlightServerDelegate instance."""
        self.server = server

    def start(self):
        """Start terminal display thread if enabled."""
        if self.display:
            self._stop_event = threading.Event()
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def stop(self):
        """Stop terminal display thread."""
        if self.display and hasattr(self, '_stop_event'):
            self._stop_event.set()
            self._thread.join(timeout=1)

    def _run(self):
        try:
            while not self._stop_event.is_set():
                self._render()
                time.sleep(self.interval)
        except KeyboardInterrupt:
            pass

    def _render(self):
        metrics = self._compute()
        # Clear screen
        sys.stdout.write("\033[2J\033[H")
        # Header
        header = f"XORQ Flight Server Metrics (Last {int(self.window)}s)"
        sys.stdout.write(header + "\n" + "=" * len(header) + "\n")
        # Print metrics
        sys.stdout.write(
            f"Requests:     {metrics['total_requests']} total | "
            f"{metrics['req_rate_avg']:.1f}/sec avg | {metrics['req_rate_current']:.1f}/sec current\n"
        )
        sys.stdout.write(
            f"Latency:      avg: {metrics['latency_avg']:.0f}ms | "
            f"p95: {metrics['latency_p95']:.0f}ms | p99: {metrics['latency_p99']:.0f}ms\n"
        )
        sys.stdout.write(
            f"Data:         {metrics['total_bytes'] / (1024**2):.2f}MB total | "
            f"{metrics['bytes_rate_avg'] / (1024**2):.2f}MB/sec avg | "
            f"{metrics['bytes_rate_current'] / (1024**2):.2f}MB/sec current\n"
        )
        sys.stdout.write(
            f"Rows:         {metrics['total_rows'] / 1e6:.1f}M total | "
            f"{metrics['rows_rate_avg'] / 1e3:.1f}K/sec avg | "
            f"{metrics['rows_rate_current'] / 1e3:.1f}K/sec current\n"
        )
        last_err = (
            f"{int(metrics['last_error_delta'])}s ago"
            if metrics['last_error_delta'] is not None
            else "n/a"
        )
        err_pct = metrics['error_pct']
        sys.stdout.write(
            f"Errors:       {metrics['total_errors']} total ({err_pct:.1f}%) | "
            f"Last: {last_err}\n"
        )
        sys.stdout.write(
            f"Connections:  {metrics['current_connections']} active | "
            f"{metrics['total_connections']} total\n"
        )
        sys.stdout.write(f"Memory:       {metrics['mem_usage_mb']:.1f}MB used\n")
        sys.stdout.flush()

    def _percentile(self, data, perc):
        if not data:
            return 0
        sorted_d = sorted(data)
        k = (len(sorted_d) - 1) * perc / 100.0
        f = int(k)
        c = min(f + 1, len(sorted_d) - 1)
        if f == c:
            return sorted_d[int(k)]
        d0 = sorted_d[f] * (c - k)
        d1 = sorted_d[c] * (k - f)
        return d0 + d1

    def _compute(self):
        now = time.monotonic()
        with self._lock:
            # Window and interval boundaries
            w0 = now - self.window
            i0 = now - self.interval
            # Requests
            reqs = [t for t in self.requests if t >= w0]
            reqs_i = [t for t in self.requests if t >= i0]
            # Latencies
            lats = [lat for t, lat in self.latencies if t >= w0]
            # Bytes
            bs = [b for t, b in self.bytes if t >= w0]
            bs_i = [b for t, b in self.bytes if t >= i0]
            # Rows
            rs = [r for t, r in self.rows if t >= w0]
            rs_i = [r for t, r in self.rows if t >= i0]
            # Errors
            errs = [t for t in self.errors if t >= w0]
            # Compute stats
            total_requests = self.total_requests
            req_rate_avg = len(reqs) / self.window if self.window > 0 else 0
            req_rate_current = len(reqs_i) / self.interval if self.interval > 0 else 0
            latency_avg = (sum(lats) / len(lats) * 1000) if lats else 0
            latency_p95 = self._percentile(lats, 95) * 1000 if lats else 0
            latency_p99 = self._percentile(lats, 99) * 1000 if lats else 0
            total_bytes = self.total_bytes
            bytes_rate_avg = sum(bs) / self.window if self.window > 0 else 0
            bytes_rate_current = sum(bs_i) / self.interval if self.interval > 0 else 0
            total_rows = self.total_rows
            rows_rate_avg = sum(rs) / self.window if self.window > 0 else 0
            rows_rate_current = sum(rs_i) / self.interval if self.interval > 0 else 0
            total_errors = self.total_errors
            error_pct = (len(errs) / len(reqs) * 100) if reqs else 0
            last_error_delta = (now - max(errs)) if errs else None
            current_connections = self.current_connections
            total_connections = self.total_connections
        # Memory usage in MB
        mem_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        mem_mb = mem_kb / 1024
        return {
            'total_requests': total_requests,
            'req_rate_avg': req_rate_avg,
            'req_rate_current': req_rate_current,
            'latency_avg': latency_avg,
            'latency_p95': latency_p95,
            'latency_p99': latency_p99,
            'total_bytes': total_bytes,
            'bytes_rate_avg': bytes_rate_avg,
            'bytes_rate_current': bytes_rate_current,
            'total_rows': total_rows,
            'rows_rate_avg': rows_rate_avg,
            'rows_rate_current': rows_rate_current,
            'total_errors': total_errors,
            'error_pct': error_pct,
            'last_error_delta': last_error_delta,
            'current_connections': current_connections,
            'total_connections': total_connections,
            'mem_usage_mb': mem_mb,
        }

    # Recording methods
    def record_request(self):
        with self._lock:
            t = time.monotonic()
            self.requests.append(t)
            self.total_requests += 1
        self._req_counter.add(1)

    def record_latency(self, latency_s):
        with self._lock:
            self.latencies.append((time.monotonic(), latency_s))
        # record in ms
        self._latency_hist.record(latency_s * 1000)

    def record_bytes(self, nbytes):
        with self._lock:
            self.bytes.append((time.monotonic(), nbytes))
            self.total_bytes += nbytes
        self._bytes_counter.add(nbytes)

    def record_rows(self, nrows):
        with self._lock:
            self.rows.append((time.monotonic(), nrows))
            self.total_rows += nrows
        self._rows_counter.add(nrows)

    def record_error(self):
        with self._lock:
            t = time.monotonic()
            self.errors.append(t)
            self.total_errors += 1
        self._errors_counter.add(1)

    def record_connection_open(self):
        with self._lock:
            self.current_connections += 1
            self.total_connections += 1
        self._conn_updown.add(1)

    def record_connection_close(self):
        with self._lock:
            self.current_connections = max(self.current_connections - 1, 0)
        self._conn_updown.add(-1)

    def wrap_reader(self, reader: pa.RecordBatchReader, start_time: float) -> pa.RecordBatchReader:
        """
        Wrap a RecordBatchReader to record bytes, rows, latency, requests, errors, and connections.
        """
        schema = reader.schema
        def gen():  # noqa: C901
            self.record_connection_open()
            try:
                for batch in reader:
                    rows = batch.num_rows
                    size = batch.get_total_buffer_size()
                    self.record_rows(rows)
                    self.record_bytes(size)
                    yield batch
            except Exception:
                self.record_error()
                raise
            finally:
                latency = time.monotonic() - start_time
                self.record_latency(latency)
                self.record_request()
                self.record_connection_close()
        return pa.RecordBatchReader.from_batches(schema, gen())