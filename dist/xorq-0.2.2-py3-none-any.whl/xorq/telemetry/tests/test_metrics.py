import time

import pyarrow as pa
import pytest

from xorq.telemetry.metrics import TelemetryCollector


def test_wrap_reader_records_metrics():
    # Create a simple RecordBatchReader with one batch
    array = pa.array([1, 2, 3])
    batch = pa.RecordBatch.from_arrays([array], ["col"])
    reader = pa.RecordBatchReader.from_batches(batch.schema, [batch])
    # Initialize collector without display
    telem = TelemetryCollector(interval=0.1, window=1.0, display=False)
    # Wrap and consume
    start = time.monotonic()
    wrapped = telem.wrap_reader(reader, start)
    total_rows = 0
    for b in wrapped:
        total_rows += b.num_rows
    # Validate consumption
    assert total_rows == 3
    # Allow slight time for metrics recording
    time.sleep(0.01)
    # Assert metrics counters
    assert telem.total_requests == 1
    assert telem.total_rows == 3
    assert telem.current_connections == 0
    assert telem.total_connections == 1
    # Bytes should be positive
    assert telem.total_bytes > 0

def test_percentile():
    telem = TelemetryCollector(display=False)
    data = [1, 2, 3, 4]
    # Use private method for percentile
    p50 = telem._percentile(data, 50)
    p75 = telem._percentile(data, 75)
    assert pytest.approx(p50) == 2.5
    assert pytest.approx(p75) == 3.25