"""
Telemetry tests package
"""