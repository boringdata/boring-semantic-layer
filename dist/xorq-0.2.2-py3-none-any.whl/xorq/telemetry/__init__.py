"""
Telemetry collection and in-memory metrics for XORQ Flight Server.
"""
from .metrics import TelemetryCollector


__all__ = ["TelemetryCollector"]